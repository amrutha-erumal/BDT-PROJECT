from pathlib import Path
from io import BytesIO
import os

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "banking_transactions.csv"
ACTIVE_DATA = ROOT / "data" / "active_transactions.csv"
REQUIRED = ["Transaction_ID", "Customer_ID", "Transaction_Date", "Transaction_Type", "Amount", "Location", "Status"]
MAX_UPLOAD_BYTES = 25 * 1024 * 1024
ALLOWED_EXTENSIONS = {".csv", ".xlsx", ".xls"}

app = FastAPI(title="Banking Transaction Intelligence API", version="1.1.0")
allowed_origins = os.getenv("VAULT_ALLOWED_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in allowed_origins if origin.strip()],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

def load_frame(upload=None):
    if upload is None:
        path = ACTIVE_DATA if ACTIVE_DATA.exists() else DATA
        df = pd.read_csv(path)
    else:
        name, content = upload
        ext = Path(name).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValueError("Unsupported file type. Upload CSV or Excel (.xlsx/.xls).")
        df = pd.read_excel(BytesIO(content)) if ext in {".xlsx", ".xls"} else pd.read_csv(BytesIO(content))

    aliases = {c.lower().replace(" ", "_"): c for c in REQUIRED}
    rename = {}
    for c in df.columns:
        key = str(c).strip().lower().replace("-", "_").replace(" ", "_")
        if key in aliases:
            rename[c] = aliases[key]
    df = df.rename(columns=rename)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))
    df = df[REQUIRED].copy()
    df["Transaction_Date"] = pd.to_datetime(df["Transaction_Date"], errors="coerce")
    df["Amount"] = pd.to_numeric(df["Amount"], errors="coerce")
    df = df.dropna(subset=["Transaction_Date", "Amount"])
    for c in ["Transaction_ID", "Customer_ID", "Transaction_Type", "Location", "Status"]:
        df[c] = df[c].astype(str).str.strip()
    return df[df.Amount >= 0]

def records(df):
    out = df.copy()
    out["Transaction_Date"] = out["Transaction_Date"].dt.strftime("%Y-%m-%d")
    return out.to_dict(orient="records")

@app.get("/api/health")
def health():
    return {"status": "ok", "version": app.version, "dataset_persistent": ACTIVE_DATA.exists()}

@app.get("/api/transactions")
def transactions():
    try:
        active = ACTIVE_DATA.exists()
        df = load_frame()
        source = "Persistent uploaded dataset" if active else "Bundled synthetic sample dataset"
        return {"source": source, "records": records(df)}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    try:
        ext = Path(file.filename or "").suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise ValueError("Unsupported file type. Upload CSV or Excel (.xlsx/.xls).")
        content = await file.read(MAX_UPLOAD_BYTES + 1)
        if len(content) > MAX_UPLOAD_BYTES:
            raise ValueError("Upload exceeds the 25 MB limit.")
        df = load_frame((file.filename, content))
        # Write only after validation succeeds; replace atomically so refresh/restart keeps the active dataset.
        ACTIVE_DATA.parent.mkdir(parents=True, exist_ok=True)
        normalized = df.copy()
        normalized["Transaction_Date"] = normalized["Transaction_Date"].dt.strftime("%Y-%m-%d")
        temp = ACTIVE_DATA.with_suffix(".tmp")
        normalized.to_csv(temp, index=False)
        temp.replace(ACTIVE_DATA)
        return {"source": f"Uploaded: {file.filename}", "records": records(df), "persisted": True}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"Could not process upload: {e}")

@app.post("/api/reset-dataset")
def reset_dataset():
    try:
        if ACTIVE_DATA.exists():
            ACTIVE_DATA.unlink()
        df = load_frame()
        return {"source": "Bundled synthetic sample dataset", "records": records(df), "reset": True}
    except Exception as e:
        raise HTTPException(500, str(e))
